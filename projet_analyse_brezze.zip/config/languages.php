<?php

return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ],
    'fr' => [
        'display' => 'Français',
        'flag-icon' => 'fr'
    ],
    'es' => [
        'display' => 'Spanish',
        'flag-icon' => 'es'
    ],
];