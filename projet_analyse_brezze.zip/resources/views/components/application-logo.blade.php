<img src="{{asset('asset/Logo-Laboratoire-Chifaa-removebg-preview.png')}}" class="img img-fluid block h-9 w-auto fill-current text-gray-800" alt="" srcset="">
                

