
<?php $__env->startSection('title'); ?>
    Modifier un résultat | Laravel ZAK-APP
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card my-2 bg-light ">
                    <div class="card-header" style="background-color:#d0497a;">
                        <div class="text-center">
                            <h3 class="text-white">Modifier un résultat</h3>
                        </div>
                    </div>
                    <div class="card-body bg-light">
                        <form method="POST" action="<?php echo e(route('admin.UpdateResultat',$data[0]->id_operation)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            
                            <div class="row mb-3">
                                <label for="resultat"class="col-md-4 col-form-label text-md-end"><?php echo e(__("Résultat d'opération")); ?></label>
                                <div class="col-md-6">
                                    <input id="resultat" type="text" class="form-control" name="resultat" value="<?php echo e(old('resultat',$data[0]->resultat)); ?>" placeholder="Veuillez saisir le résultat d'opération"  required autofocus>
                                    <?php $__errorArgs = ['resultat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="op"class="col-md-4 col-form-label text-md-end"><?php echo e(__("Date d'opération")); ?></label>
                                <div class="col-md-6">
                                    <input id="op" type="date" class="form-control" name="date_operation" value="<?php echo e(old('date_operation',$data[0]->date_operation)); ?>" required autofocus>
                                    <?php $__errorArgs = ['date_operation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="resultat"class="col-md-4 col-form-label text-md-end"><?php echo e(__("Date de résultat")); ?></label>
                                <div class="col-md-6">
                                    <input id="resultat" type="date" class="form-control" name="date_resultat" value="<?php echo e(old('date_resultat',$data[0]->date_resultat)); ?>" required autofocus>
                                    <?php $__errorArgs = ['date_resultat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-0">
                                <div class="col-md-6 mt-1 offset-4 ">
                                    <button type="submit" class="btn btn-outline-pink text-center w-100">
                                        <?php echo e(__('Modifier')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Admin/modifier_resultat.blade.php ENDPATH**/ ?>