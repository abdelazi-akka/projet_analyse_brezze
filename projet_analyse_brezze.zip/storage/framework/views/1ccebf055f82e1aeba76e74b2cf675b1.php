<?php echo e($slot); ?>

<?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>