
<?php $__env->startSection('title'); ?>
    Ajouter un employe | ZAK-APP
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card my-2 bg-light ">
                    <div class="card-header" style="background:#d0497a">
                        <div class="text-center">
                            <h3 class="text-white" >Ajouter un nouveau employé</h3>
                        </div>
                    </div>
                    <div class="card-body bg-light">
                        <form method="POST" action="<?php echo e(route('employes.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="cin"class="col-md-4 col-form-label text-md-end"><?php echo e(__('CIN')); ?></label>
                                <div class="col-md-6">
                                    <input id="cin" type="text" class="form-control" name="cin" value="<?php echo e(old('cin')); ?>" placeholder="Veuillez saisir le CIN" required autofocus>
                                    <?php $__errorArgs = ['cin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="nom"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Nom')); ?></label>
                                <div class="col-md-6">
                                    <input id="nom" type="text" class="form-control" name="nom" value="<?php echo e(old('nom')); ?>" placeholder="Veuillez saisir le nom" required autofocus>
                                    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="prenom"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Prénom')); ?></label>
                                <div class="col-md-6">
                                    <input id="prenom" type="text" class="form-control" name="prenom" value="<?php echo e(old('prenom')); ?>" placeholder="Veuillez saisir le prénom" required autofocus>
                                    <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="adress"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Adress')); ?></label>
                                <div class="col-md-6">
                                    <input id="adress" type="text" class="form-control" name="adress" value="<?php echo e(old('adress')); ?>" placeholder="Veuillez saisir l'adress" required autofocus>
                                    <?php $__errorArgs = ['adress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="telephone"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Télephonne')); ?></label>
                                <div class="col-md-6">
                                    <input id="telephone" type="text" class="form-control" name="telephone" value="<?php echo e(old('telephone')); ?>" placeholder="Veuillez saisir le Télephonne" required autofocus>
                                    <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="date"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Date de Recrutement')); ?></label>
                                <div class="col-md-6">
                                    <input id="date" type="date" class="form-control" name="date_recrutement" value="<?php echo e(old('date_recrutement')); ?>"  required autofocus>
                                    <?php $__errorArgs = ['date_recrutement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-outline-pink w-100">
                                        <?php echo e(__('Ajouter')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Admin/Ajouter_employe.blade.php ENDPATH**/ ?>