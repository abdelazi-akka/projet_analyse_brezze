<style>
#search-form-unique:hover{
    background-color: #d0497a !important;
}
</style>
<li id="search-form-unique">

    <div class="form-inline my-2">
        <div class="input-group" data-widget="sidebar-search" data-arrow-sign="&raquo;">

            
            <input class="form-control bg-white form-control-sidebar" type="search"
                <?php if(isset($item['id'])): ?> id="<?php echo e($item['id']); ?>" <?php endif; ?>
                placeholder="<?php echo e($item['text']); ?>"
                aria-label="<?php echo e($item['text']); ?>">

            
            <div class="input-group-append">
                <button class="btn btn-sidebar bg-pink">
                    <i class="fas fa-fw fa-search text-white"></i>
                </button>
            </div>

        </div>
    </div>

</li>
<?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/menu-item-search-menu.blade.php ENDPATH**/ ?>