
<?php $__env->startSection('plugins.Datatables',true); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card my-2 bg-light "> 
                <div class="card-header" style="background-color:#d0497a;">
                    <div class="text-center">
                        <h3 class="text-white">La Listes des paiements</h3>
                    </div>
                </div>
                <div class="card-body" style="overflow-x:auto;">
                    <table id="mytable" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>ID Opération</th>
                                <th>Nom & Prénom</th>
                                <th>CIN</th>
                                <th>Désignation</th>
                                <th>Prix</th>
                                <th>Date d'opération</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td data-label="ID Opération"><?php echo e($item->id_operation); ?></td>
                                <td data-label="Nom & Prénom"><?php echo e($item->nom); ?> & <?php echo e($item->prenom); ?></td>
                                <td data-label="CIN"><?php echo e($item->cin); ?></td>
                                <td data-label="Désignation"><?php echo e($item->designation); ?></td>
                                <td data-label="Prix"><?php echo e($item->prix); ?> DH</td>
                                <td data-label="Date d'opération"><?php echo e($item->date_operation); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                        
                        
                    </table>
                </div>
            </div>
            
            
        </div>
    </div>
</div>
<!--***********************************************************************************************************************************************************-->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card my-2 bg-light "> 
                <div class="card-header" style="background-color:#d0497a;">
                    <div class="text-center">
                        <h3 class="text-white">La Listes des paiements(jours)</h3>
                    </div>
                </div>
                <div class="card-body" style="overflow-x:auto;">
                <table id="mytable" class="table table-bordered table-striped ">
                    <thead>
                        <tr class="text-center">
                            <th>Date du Jour</th>
                            <th>Total des opérations</th>
                            <th>Total Prix du jour</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td data-label="Date du Jour"><?php echo e($item2->date_operation); ?></td>
                            <td data-label="Total des opérations"><?php echo e($item2->totalOperation); ?></td>
                            <td data-label="Total Prix du jours"><?php echo e(number_format($item2->sumPrix,2)); ?> DH</td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<!--***********************************************************************************************************************************************************-->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card my-2 bg-light "> 
                <div class="card-header" style="background-color:#d0497a;">
                    <div class="text-center">
                        <h3 class="text-white">La Listes des paiements(mois)</h3>
                    </div>
                </div>
                <div class="card-body" style="overflow-x:auto;">
                    <table id="mytable" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>Année</th>
                                <th>Mois</th>
                                <th>Total des opérations</th>
                                <th>Prix</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td data-label="Année"><?php echo e($item->anne); ?></td>
                                <td data-label="Mois"><?php echo e($item->month); ?></td>
                                <td data-label="Total des opérations"><?php echo e($item->totalOperation); ?></td>
                                <td data-label="Prix"><?php echo e(number_format($item->totalPrix,2)); ?> DH</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
        </div>
    </div>
</div>
</div>
<!--***********************************************************************************************************************************************************-->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card my-2 bg-light "> 
                <div class="card-header" style="background-color:#d0497a;">
                    <div class="text-center">
                        <h3 class="text-white">La Listes des paiements(année)</h3>
                    </div>
                </div>
                <div class="card-body" style="overflow-x:auto;">
                <table id="mytable" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>Année</th>
                                <th>Total des opérations</th>
                                <th>Prix</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td data-label="Année"><?php echo e($item->anne); ?></td>
                                <td data-label="Total des opérations"><?php echo e($item->totalOperation); ?></td>
                                <td data-label="Prix"><?php echo e(number_format($item->totalPrix,2)); ?> DH</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function(){
        $('.table').DataTable({
            dom:'Bfrtip',
            buttons:['copy','excel','csv','pdf','print','colvis'],
            "pageLength": 3,
            "language": {
                "sEmptyTable":    "",
                "sInfo":          "Affichage de _START_ à _END_ sur _TOTAL_ entrées ",
                "sSearch":        "Chercher:",
        "oPaginate": {
            
            "sNext":    "Suivant",
            "sPrevious": "Précedent"
        },
        
    }
        })
    })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Admin/liste_payments.blade.php ENDPATH**/ ?>