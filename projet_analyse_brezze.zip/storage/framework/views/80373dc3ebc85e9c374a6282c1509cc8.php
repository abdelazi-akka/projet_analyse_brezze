

<?php $__env->startSection('title'); ?>
    Dashboard Admin | GSM-APP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .small-box {
        background: linear-gradient(
            to right, #8be4ec, #d6dd139b, #9aba9c, #9b5d61, #acac6c, #8e8eb9);
        background-size: 400% 400%;
        animation: animate-background 10s infinite ease-in-out;
    }

    @keyframes animate-background {
        0% {
            background-position: 0 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0 50%;
        }
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="card my-2 bg-light">
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $data->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="row">
                        <?php ($icons = ["fas fa-prescription-bottle", "fas fa-solid fa-hand-holding-medical", "fas fa-vial", "fas fa-flask"]); ?>
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <div class="small-box text-white">
                                <div class="inner">
                                    <h3><?php echo e($add->abrv); ?></h3>
                                    <p><?php echo e($add->designation); ?></p>
                                </div>
                                <div class="icon">
                                    <i class="<?php echo e($icons[array_rand($icons)]); ?>"></i>
                                </div>
                                <a href="<?php echo e(route('analyses.show', $add->id_analyse)); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No data available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Employes/liste_analyses.blade.php ENDPATH**/ ?>