<aside class="main-sidebar <?php echo e(config('adminlte.classes_sidebar', 'sidebar-dark-primary elevation-4')); ?>"
style="background:#d0497a;transition: 0.5s;overflow: hidden">
<style>
    :root {
--blue: #2a2185;
--white: #fff;
--gray: #f5f5f5;
--black1: #222;
--black2: #999;
} 
 .sidebar nav ul li {
border-top-left-radius: 30px;
border-bottom-left-radius: 30px;
}
.sidebar nav ul li:hover {
background-color: var(--white);
color: #d0497a !important;
}
.sidebar nav ul li a:hover {
color: #d0497a !important;
}
.sidebar nav ul li a {
color:white !important;
}
.sidebar nav ul li a.active{
border-top-left-radius: 30px !important;
border-bottom-left-radius: 30px !important;
background-color: var(--white) !important;
color: #d0497a !important;

}
</style>
    
    <?php if(config('adminlte.logo_img_xl')): ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xl', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('adminlte::partials.common.brand-logo-xs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <div class="sidebar">
        <nav class="pt-2">
            <ul class="nav nav-pills nav-sidebar flex-column <?php echo e(config('adminlte.classes_sidebar_nav', '')); ?>"
                data-widget="treeview" role="menu"
                <?php if(config('adminlte.sidebar_nav_animation_speed') != 300): ?>
                    data-animation-speed="<?php echo e(config('adminlte.sidebar_nav_animation_speed')); ?>"
                <?php endif; ?>
                <?php if(!config('adminlte.sidebar_nav_accordion')): ?>
                    data-accordion="false"
                <?php endif; ?>>
                
                <?php echo $__env->renderEach('adminlte::partials.sidebar.menu-item', $adminlte->menu('sidebar'), 'item'); ?>
            </ul>
        </nav>
    </div>

</aside>
<?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/sidebar/left-sidebar.blade.php ENDPATH**/ ?>