<img src="<?php echo e(asset('asset/Logo-Laboratoire-Chifaa-removebg-preview.png')); ?>" class="img img-fluid block h-9 w-auto fill-current text-gray-800" alt="" srcset="">
                

<?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/components/application-logo.blade.php ENDPATH**/ ?>