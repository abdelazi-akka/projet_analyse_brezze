 
<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        
        <div class="col-12">
            <div class="card my-2 bg-light">
                <div class="card-body">
                    <div class="row">
                        <!-- /***************************************************************** */ -->
                        <div class="col-4">
                            <div class="small-box bg-gradient-danger">
                                <div class="inner">
                                    <h3 class="text-white"><?php echo e(\App\Models\Employe::count()); ?></h3>
                                    <p class="text-white">Nombre des employes</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-users text-white"></i>
                                </div>
                                <a href="<?php echo e(route('employes.index')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- /***************************************************************** */ -->
                        <div class="col-4">
                            <div class="small-box bg-gradient-gray">
                                <div class="inner">
                                    <h3 class="text-white"><?php echo e(\App\Models\Analyse::count()); ?></h3>
                                    <p class="text-white">Nombre des analyses</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-solid fa-vials text-white"></i>
                                </div>
                                <a href="<?php echo e(route('analyse.index')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- /***************************************************************** */ -->
                        <div class="col-4">
                            <div class="small-box bg-gradient-success">
                                <div class="inner">
                                    <h3 class="text-white"><?php echo e($NombreResultat); ?></h3>
                                    <p>Nombre des résultats</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-solid fa-receipt text-white"></i>
                                </div>
                                <a href="<?php echo e(route('admin.AfficherResultat')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /***************************************************************** */ -->
                    <div class="row">
                        <div class="col-4">
                            <div class="small-box bg-gradient-pink">
                                <div class="inner">
                                <h3 class="text-white"><?php $__empty_1 = true; $__currentLoopData = $PayementJour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php echo e($item->sumPrix); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 0 <?php endif; ?></h3>
                                    <p class="text-white">Total pour le jour <?php echo e(date("Y-m-d")); ?> en DH</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-solid fa-money-bill text-white"></i>
                                </div>
                                <a href="<?php echo e(route('admin.AfficherResultat')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- /***************************************************************** */ -->
                        <div class="col-4">
                            <div class="small-box bg-gradient-orange">
                                <div class="inner">
                                <h3 class="text-white"><?php $__empty_1 = true; $__currentLoopData = $PayementMois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php echo e($item->totalPrix); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 0 <?php endif; ?></h3>
                                    <p class="text-white">Total pour le mois 
                                        <?php $__currentLoopData = $PayementMois; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item->month); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    en DH</p>
                                </div>
                                <div class="icon">
                                <i class="fas fa-solid fa-money-bill text-white"></i>
                                </div>
                                <a href="<?php echo e(route('admin.AfficherResultat')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- /***************************************************************** */ -->
                        <div class="col-4">
                            <div class="small-box bg-gradient-info">
                                <div class="inner">
                                <h3 class="text-white"><?php $__empty_1 = true; $__currentLoopData = $PayementAnne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php echo e($item->totalPrix); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 0 <?php endif; ?></h3>
                                    <p>Total pour l'année 
                                        <?php $__currentLoopData = $PayementAnne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($item->anne); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                    en DH</p>
                                </div>
                                <div class="icon">
                                <i class="fas fa-solid fa-money-bill text-white"></i>
                                </div>
                                <a href="<?php echo e(route('admin.AfficherResultat')); ?>" class="small-box-footer">
                                    Plus d'infos <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("adminlte::page", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Admin/Dashboard.blade.php ENDPATH**/ ?>