

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card my-2  bg-light ">
                    <div class="card-header" style="background-color: #d0497a">
                        <div class="text-center">
                            <h3 class="text-white">Ajouter une opération</h3>
                        </div>
                    </div>
                    <div class="card-body bg-light">
                        <form method="POST" action="<?php echo e(route('analyses.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <label for="analyse"class="col-md-4 col-form-label text-md-end"><?php echo e(__("La désignation du l'analyse")); ?></label>
                                <div class="col-md-6">
                                    <select name="id_analyse" id="analyse" class="form-control">
                                        <?php $__currentLoopData = $analyses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id_analyse); ?>">Designation:<?php echo e($item->designation); ?> | prix:<?php echo e($item->prix); ?> DH</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="client"class="col-md-4 col-form-label text-md-end"><?php echo e(__("Client")); ?></label>
                                <div class="col-md-6">
                                    <select name="id_client" id="client" class="form-control">
                                        <option value="<?php echo e($data->id_client); ?>">Nom :<?php echo e($data->nom); ?> | Prénom :<?php echo e($data->prenom); ?> | cin :<?php echo e($data->cin); ?></option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="date_operation"class="col-md-4 col-form-label text-md-end"><?php echo e(__("Date d'opération")); ?></label>
                                <div class="col-md-6">
                                    <input id="date_operation" type="date" class="form-control" name="date_operation" value="<?php echo e(old('date_operation')); ?>" required autofocus>
                                    <?php $__errorArgs = ['date_operation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-outline-pink w-100">
                                        <?php echo e(__('Ajouter')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Employes/ajouter_operation.blade.php ENDPATH**/ ?>