

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card my-3 mx-3 bg-light ">
                    <div class="card-header" style="background-color: #d0497a;">
                        <div class="text-center">
                            <h3 class="text-white">Modifier une analyse</h3>
                        </div>
                    </div>
                    <div class="card-body bg-light">
                        <form method="POST" action="<?php echo e(route('analyse.update',$data->id_analyse)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row mb-3">
                                <label for="abréviation"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Abréviation')); ?></label>
                                <div class="col-md-6">
                                    <input id="abréviation" type="text" class="form-control" name="abrv" value="<?php echo e(old('abréviation',$data->abrv)); ?>" placeholder="Veuillez saisir l'abréviation d'analyse" required autofocus>
                                    <?php $__errorArgs = ['abrv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3">
                                <label for="designation"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Désignation')); ?></label>
                                <div class="col-md-6">
                                    <input id="designation" type="text" class="form-control" name="designation" value="<?php echo e(old('designation',$data->designation)); ?>" placeholder="Veuillez saisir le désignation d'analyse" required autofocus>
                                    <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <label for="prix"class="col-md-4 col-form-label text-md-end"><?php echo e(__('Prix')); ?></label>
                                <div class="col-md-6">
                                    <input id="prix" type="text" class="form-control" name="prix" value="<?php echo e(old('prix',$data->prix)); ?>" placeholder="Veuillez saisir le prix d'analyse" required autofocus>
                                    <?php $__errorArgs = ['prix'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="norme"class="col-md-4 col-form-label text-md-end">La norme d'analyse</label>
                                <div class="col-md-6">
                                    <input id="norme" type="text" class="form-control" name="norme" value="<?php echo e(old('norme',$data->norme)); ?>" placeholder="Veuillez saisir la norme d'analyse" required autofocus>
                                    <?php $__errorArgs = ['norme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="unite"class="col-md-4 col-form-label text-md-end">L'unité de mesure'</label>
                                <div class="col-md-6">
                                    <input id="unite" type="text" class="form-control" name="unite" value="<?php echo e(old('unite',$data->unite)); ?>" placeholder="Veuillez saisir L'unité de mesure d'analyse" required autofocus>
                                    <?php $__errorArgs = ['unite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-outline-pink w-100">
                                        <?php echo e(__('Modifier')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Admin/modifier_analyse.blade.php ENDPATH**/ ?>