
<?php $__env->startSection('title'); ?>
    Show Client | Laravel ZAK-APP
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div class="card my-2 bg-light">
                    <div class="card-header" style="background-color: #d0497a">
                        <div class="text-center">
                            <h3 class="text-white">Les détailles du patient</h3>
                        </div>
                    </div>
                    <div class="row card-body">
                        <div class="col-6 form-group mb-3">
                            <label >Prénom</label>
                            <input  class="form-control" value="<?php echo e($data->prenom); ?>"readonly>
                        </div>
                        <div class="col-6 form-group mb-3">
                            <label >Nom</label>
                            <input  class="form-control" value="<?php echo e($data->nom); ?>"  readonly>
                        </div>
                    </div>
                    <div class="row card-body">
                        <div class="col-6 form-group mb-3">
                            <label>Date de Visite</label>
                            <input  class="form-control" value="<?php echo e($data->date_inscription); ?>" readonly>
                        </div>

                        <div class=" col-6 form-group mb-3">
                            <label >CIN</label>
                            <input  class="form-control" value="<?php echo e($data->cin); ?>" readonly>
                        </div>
                    </div>
                    <div class="row card-body">
                        <div class="col-6 form-group mb-3">
                            <label >Age</label>
                            <input  class="form-control" value="<?php echo e($data->age); ?>" readonly>
                        </div>
                        <div class=" col-6 form-group mb-3">
                            <label>Telephone</label>
                            <input  class="form-control" value="<?php echo e($data->telephone); ?>"readonly>
                        </div>
                    </div>
                    <div class="row card-body">
                        <div class="col-md-6 offset-3 mb-3">
                            <a class="btn btn-outline-pink w-100" href="<?php echo e(route('patients.index')); ?>">Retour</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampkhalid\htdocs\projet_analyse_brezze\resources\views/Employes/details_patients.blade.php ENDPATH**/ ?>